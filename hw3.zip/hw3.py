# coding = utf-84
import os
import subprocess
import pandas
from pandas import Series
from pandas import DataFrame
import numpy
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn.naive_bayes import GaussianNB
from sklearn.cluster import *
import matplotlib.pyplot as pyplot
def encode_target(df, target_column):
    df_mod = df.copy()
    for i in target_column:
        targets = df_mod[i].unique()
        map_to_int = {name: n for n, name in enumerate(targets)}
        df_mod[i] = df_mod[i].replace(map_to_int)
    return df_mod


DataFile1 = open("F:/Users/andy/Documents/GitHub/train.csv",encoding='gb18030',errors='ignore')
DataFile2 = open('F:/Users/andy/Documents\GitHub/test.csv',encoding='gb18030',errors='ignore')
TrainSet = pandas.read_csv(DataFile1)
TestSet = pandas.read_csv(DataFile2)
NominalAttribute = ['Pclass', 'Sex', 'Cabin', 'Embarked']
NumericAttribute = ['SibSp', 'Age', 'Parch', 'Fare']
# 丢弃有空值行
TrainSet = TrainSet.dropna(axis=0, how='any')

#预处理
TestSet['Age'] = TestSet['Age'].fillna(value=TestSet['Age'].mean())
TestSet['Fare'] = TestSet['Fare'].fillna(value=TestSet['Fare'].mean())
to_encode_attr = ['Embarked', 'Cabin', 'Ticket'];
TrainSet = encode_target(TrainSet, to_encode_attr)
TestSet = encode_target(TestSet, to_encode_attr)
TrainSet[['Age', 'Fare']] = TrainSet[['Age', 'Fare']].astype(int)
TestSet[['Age', 'Fare']] = TestSet[['Age', 'Fare']].astype(int)
# 特征属性与标签属性
LabelAttr = ['Survived']
FeatureAttr = ['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Cabin', 'Embarked', 'Ticket'];
Label = TrainSet[LabelAttr]
Feature = TrainSet[FeatureAttr]
# 决策树
DesicionTree = DecisionTreeClassifier(criterion='entropy', max_depth=8)
DesicionTree.fit(Feature, Label)
result1 = DesicionTree.predict(TestSet)
print( '决策树判断生还者:', Series(result1).sum())
#朴素贝叶斯分类器
GaussianNaiveBayesClassifier = GaussianNB().fit(Feature, Label)
result2 = GaussianNaiveBayesClassifier.predict(TestSet)
print('贝叶斯判断生还者:', Series(result2).sum())
#结果
pyplot.figure()
temp = pandas.concat([DataFrame(result1, columns=['Survived']), TestSet[['Age', 'Pclass']]], axis=1)
alive = temp.loc[temp['Survived'] == 1]
dead = temp.loc[temp['Survived'] == 0]

figure1 = pyplot.subplot(1, 1, 1)
pyplot.rcParams['font.sans-serif'] = ['SimHei']
figure1.set_title(u'决策树预测')
alive_distribute = figure1.scatter(alive['Age'], alive['Pclass'], c='green', marker='^')
dead_distribute = figure1.scatter(dead['Age'], dead['Pclass'], c='red', marker='*')
pyplot.xlabel(u'age')
pyplot.ylabel(u'pclass')
figure1.legend((alive_distribute, dead_distribute), ('dead', 'alive'), loc=1)

pyplot.show()
pyplot.figure()
temp = pandas.concat([DataFrame(result2, columns=['Survived']), TestSet[['Age', 'Pclass']]], axis=1)
alive = temp.loc[temp['Survived'] == 1]
dead = temp.loc[temp['Survived'] == 0]

figure2 = pyplot.subplot(1, 1, 1)
pyplot.rcParams['font.sans-serif'] = ['SimHei']
figure2.set_title(u'贝叶斯预测')
alive_distribute = figure2.scatter(alive['Age'], alive['Pclass'], c='green', marker='^')
dead_distribute = figure2.scatter(dead['Age'], dead['Pclass'], c='red', marker='*')
pyplot.xlabel(u'age')
pyplot.ylabel(u'pclass')
figure2.legend((alive_distribute, dead_distribute), ('dead', 'alive'), loc=1)

pyplot.show()


DataFile1 = open("F:/Users/andy/Documents/GitHub/train.csv",encoding='gb18030',errors='ignore')
DataFile2 = open('F:/Users/andy/Documents\GitHub/test.csv',encoding='gb18030',errors='ignore')
TrainSet = pandas.read_csv(DataFile1)
TestSet = pandas.read_csv(DataFile2)

NominalAttribute = ['Pclass', 'Sex', 'Cabin', 'Embarked', 'Ticket']
NumericAttribute = ['SibSp', 'Age', 'Parch', 'Fare']

#预处理
to_encode_attr = ['Embarked', 'Cabin', 'Ticket'];
TrainSet = encode_target(TrainSet, to_encode_attr)
TrainSet['Age'] = TrainSet['Age'].fillna(value=TrainSet['Age'].mean())

# k均值聚类
kmeans_cluster = KMeans(n_clusters=5, random_state=0).fit(TrainSet)
# DBSCAN聚类
dbscan_cluster = DBSCAN(eps=15, min_samples=5).fit(TrainSet)

# 显示聚类结果
pyplot.figure()
# kmeans聚类结果显示
temp = pandas.concat([DataFrame(kmeans_cluster.labels_, columns=['ClassLabel']), TrainSet], axis=1)
type1 = temp.loc[temp['ClassLabel'] == 0]
type2 = temp.loc[temp['ClassLabel'] == 1]
type3 = temp.loc[temp['ClassLabel'] == 2]
type4 = temp.loc[temp['ClassLabel'] == 3]
type5 = temp.loc[temp['ClassLabel'] == 4]
figure1 = pyplot.subplot(1, 1, 1)
pyplot.rcParams['font.sans-serif'] = ['SimHei']
figure1.set_title(u'K-means聚类结果')
type1_distribute = figure1.scatter(type1['Age'], type1['Fare'], c='green', marker='d')
type2_distribute = figure1.scatter(type2['Age'], type2['Fare'], c='red', marker='*')
type3_distribute = figure1.scatter(type3['Age'], type3['Fare'], c='yellow', marker='p')
type4_distribute = figure1.scatter(type4['Age'], type4['Fare'], c='brown')
type5_distribute = figure1.scatter(type5['Age'], type5['Fare'], c='blue', marker='^')
pyplot.xlabel(u'age')
pyplot.ylabel(u'fare')
figure1.legend((type1_distribute, type2_distribute, type3_distribute,type4_distribute,type5_distribute), ('type1', 'type2', 'type3','type4', 'type5'),
               loc=1)
pyplot.show()
pyplot.figure()
# DBSCAN聚类结果显示
temp = pandas.concat([DataFrame(dbscan_cluster.labels_, columns=['ClassLabel']), TrainSet], axis=1)
temp = temp.drop(temp[temp['ClassLabel'] == -1].index)
type1 = temp.loc[temp['ClassLabel'] == 0]
type2 = temp.loc[temp['ClassLabel'] == 1]
type3 = temp.loc[temp['ClassLabel'] == 2]
type4 = temp.loc[temp['ClassLabel'] == 3]

figure2 = pyplot.subplot(1, 1, 1)
pyplot.rcParams['font.sans-serif'] = ['SimHei']
figure2.set_title(u'DBSCAN聚类结果')

type1_distribute = figure2.scatter(type1['Age'], type1['Fare'], c='green', marker='d')
type2_distribute = figure2.scatter(type2['Age'], type2['Fare'], c='red', marker='*')
type3_distribute = figure2.scatter(type3['Age'], type3['Fare'], c='yellow', marker='p')
type4_distribute = figure2.scatter(type4['Age'], type4['Fare'], c='brown')

pyplot.xlabel(u'age')
pyplot.ylabel(u'fare')
figure2.legend((type1_distribute, type2_distribute, type3_distribute,type4_distribute), ('type1', 'type2', 'type3','type4'),
               loc=1)

pyplot.show()

